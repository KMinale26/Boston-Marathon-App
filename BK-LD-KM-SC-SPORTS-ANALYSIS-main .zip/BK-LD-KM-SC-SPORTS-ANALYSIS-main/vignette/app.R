#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(tidyverse)
library(ggplot2)
library(bslib)
library(scales)
library(DT)
library(thematic)
library(shinyWidgets)

thematic_shiny(font = "auto")

ui <- fluidPage(
  theme = bslib::bs_theme(version = 5, bootswatch = "materia"),
  sidebarLayout(
    sidebarPanel(
      pickerInput(
        "gender", "Select Gender",
        choices = c("All", "M", "W"),
        selected = "All",
        multiple = FALSE
      ),
      pickerInput(
        "age_group", "Select Age Group",
        choices = NULL,
        multiple = TRUE,
        selected = NULL,
        options = pickerOptions(
          liveSearch = TRUE,
          actionsBox = TRUE
        )
      ),
      sliderInput(
        "time", "Finish Time Range (Minutes)",
        min = 0, max = 600, value = c(0, 600)
      ),
      downloadButton('downFile', label = "Download Filtered Data")
    ),
    mainPanel(
      tabsetPanel(
        tabPanel(
          "Overview",
          h3("Boston Marathon 2023 Data"),
          dataTableOutput("summary_table")
        ),
        tabPanel(
          "Visualizations",
          plotOutput("boxplot_performance"),
          h4("Linear Regression Models"),
          verbatimTextOutput("lm_minutes_summary"),
          verbatimTextOutput("lm_seconds_summary")
        )
      )
    )
  )
)

server <- function(input, output, session) {
  
  marathon_data <- reactive({
    df <- read.csv("data-raw/boston_marathon_2023.csv")
    print(names(df))
    return(df)
  })
  
  filtered_data <- reactive({
    df <- marathon_data()
    if("finish_net_minutes" %in% names(df)) {
      df <- df %>%
        filter(
          age_group %in% input$age_group,
          finish_net_minutes >= input$time[1], finish_net_minutes <= input$time[2]
        )
    } else {
      stop("Column 'finish_net_minutes' not found.")
    }
    return(df)
  })
  
  observe({
    df <- marathon_data()
    gender_data <- df
    if (input$gender != "All") {
      gender_data <- gender_data %>% filter(gender == input$gender)
    }
    updatePickerInput(
      session,
      "age_group",
      choices = unique(gender_data$age_group),
      selected = unique(gender_data$age_group)
    )
  })
  
  output$summary_table <- renderDataTable({
    filtered_data() %>%
      group_by(age_group, gender) %>%
      summarise(
        Total_Runners = n(),
        Avg_Finish_Time = mean(finish_net_minutes, na.rm = TRUE),
        .groups = "drop"
      )
  })
  
  output$boxplot_performance <- renderPlot({
    ggplot(filtered_data(), aes(x = age_group, y = finish_net_minutes, fill = gender)) +
      geom_boxplot() +
      labs(
        title = "Distribution of Finish Times by Age Group and Gender",
        x = "Age Group",
        y = "Finish Time (Minutes)"
      ) +
      theme_minimal() +
      theme(axis.text.x = element_text(angle = 45, hjust = 1))
  })
  
  lm_model_minutes <- reactive({
    df <- filtered_data()
    lm(finish_net_minutes ~ age_group * gender, data = df)
  })
  
  lm_model_seconds <- reactive({
    df <- filtered_data()
    lm(finish_net_sec ~ age_group * gender, data = df)
  })
  
  output$lm_minutes_summary <- renderPrint({
    lm_model <- lm_model_minutes()
    summary(lm_model)
  })
  
  output$lm_seconds_summary <- renderPrint({
    lm_model <- lm_model_seconds()
    summary(lm_model)
  })
  
  output$downFile <- downloadHandler(
    filename = "filtered_marathon_data.csv",
    content = function(file) {
      write.csv(filtered_data(), file, row.names = FALSE)
    }
  )
}

shinyApp(ui = ui, server = server)
